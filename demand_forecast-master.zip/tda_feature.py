import numpy as np
from gtda.time_series import SlidingWindow
from gtda.homology import VietorisRipsPersistence
from gtda.diagrams import Amplitude
from sklearn.ensemble import RandomForestRegressor
from gtda.pipeline import make_pipeline
from gtda.time_series import TakensEmbedding
import pandas as pd
import matplotlib.pyplot as plt
from gtda.time_series import Labeller
from sklearn.metrics import mean_squared_error, mean_absolute_error
from metrics import metric



# data = pd.read_csv("./data/new_data.csv",encoding='gbk')
# # print(data.head())

def get_feature(load):

    X = load
    y_true = load

    Lab = Labeller(size=1, func=np.max)
    Xl, yl = Lab.fit_transform_resample(X, X)
    # print("XL",np.shape(Xl))

    # window_size = 8
    # stride = 2

    SW = SlidingWindow(size=5)
    X_sw, yr = SW.fit_transform_resample(Xl, y_true)
    # print("X_sw", np.shape(X_sw))

    TE = TakensEmbedding(time_delay=1, dimension=2)
    X_te = TE.fit_transform(X_sw)
    # print("X_te", np.shape(X_te))

    VR = VietorisRipsPersistence()
    Ampl = Amplitude()

    X_vr = VR.fit_transform(X_te)  # "precomputed" required on dissimilarity data

    X_a = Ampl.fit_transform(X_vr)

    return X_a




if __name__ == "__main__":

    data = pd.read_csv("E:\\电网\\概率预测\\demand_forecast-master\\data\\new.csv", encoding='gbk')
    # print(data.head())
    load = data['Load'].values
    X = load[:384]
    y_true = load[384:768]

    X_a = get_feature(X)

    RFR = RandomForestRegressor()

    RFR.fit(X_a, y_true[5:])
    y_pred1 = RFR.predict(X_a)



    X1 = np.array(X).reshape(-1, 1)
    y2 = np.array(y_true).reshape(-1, 1)
    RFR.fit(X1, y2)
    y_pred2 = RFR.predict(X1)



    mae1, mse1, _, _, _ = metric(y_pred1, y_true[5:])

    mae2, mse2, _, _, _ = metric(y_pred2, y_true)
    print("RF_MAE: {}".format(mae2))
    print("TDA_MAE: {}".format(mae1))
    print("RF_MSE: {}".format(mse2))
    print("TDA_MSE: {}".format(mse1))


    plt.figure(figsize=(20, 6))

    plt.subplot(1, 2, 1)
    plt.plot(y_true, label='true')
    plt.plot(y_pred2, label='pred')
    plt.title("RFR")
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.plot(y_true[5:], label='true')
    plt.plot(y_pred1, label='pred')
    plt.title("TDA")
    plt.legend()

    plt.show()

