import pandas as pd
import util
import os
from datetime import date
import numpy as np
from gtda.time_series import SingleTakensEmbedding
from gtda.plotting import plot_point_cloud
import plotly as py
import matplotlib.pyplot as plt

'''
data_path = util.get_data_path()
data = pd.read_csv(os.path.join(data_path, "LD_MT200_hour.csv"), parse_dates=["date"])
data["year"] = data["date"].apply(lambda x: x.year)
data["day_of_week"] = data["date"].apply(lambda x: x.dayofweek)
data = data.loc[(data["date"].dt.date >= date(2014, 1, 1)) & (data["date"].dt.date <= date(2014, 2, 1))]

features = ["hour", "day_of_week"]
# hours = pd.get_dummies(data["hour"])
# dows = pd.get_dummies(data["day_of_week"])
hours = data["hour"]
dows = data["day_of_week"]
X = np.c_[np.asarray(hours), np.asarray(dows)]
num_features = X.shape[1]
num_periods = len(data)
X = np.asarray(X).reshape((-1, num_periods, num_features))
#y = np.asarray(data["MT_200"]).reshape((-1, num_periods))

y = np.asarray(data["MT_200"])
print(type(y))

embedding_dimension_nonperiodic = 3
embedding_time_delay_nonperiodic = 24
stride = 2

embedder_nonperiodic = SingleTakensEmbedding(
    parameters_type="fixed",
    n_jobs=2,
    time_delay=embedding_time_delay_nonperiodic,
    dimension=embedding_dimension_nonperiodic,
    stride=stride,
)

y_nonperiodic_embedded = embedder_nonperiodic.fit_transform(y)

fig = plot_point_cloud(y_nonperiodic_embedded)

py.offline.plot(fig,filename="./iris1.html")
'''

import numpy as np
import plotly.graph_objects as go

x_periodic = np.linspace(0, 10, 1000)
y_periodic = np.cos(5 * x_periodic)

# fig = go.Figure(data=go.Scatter(x=x_periodic, y=y_periodic))
# fig.update_layout(xaxis_title="Timestamp", yaxis_title="Amplitude")
# fig.show()

from gtda.time_series import SingleTakensEmbedding

embedding_dimension_periodic = 3
embedding_time_delay_periodic = 8
stride = 10

embedder_periodic = SingleTakensEmbedding(
    parameters_type="fixed",
    n_jobs=2,
    time_delay=embedding_time_delay_periodic,
    dimension=embedding_dimension_periodic,
    stride=stride,
)

y_periodic_embedded = embedder_periodic.fit_transform(y_periodic)
print(f"Shape of embedded time series: {y_periodic_embedded.shape}")

from gtda.plotting import plot_point_cloud

fig = plot_point_cloud(y_periodic_embedded)
py.offline.plot(fig,filename="./iris2.html")
fig.show()